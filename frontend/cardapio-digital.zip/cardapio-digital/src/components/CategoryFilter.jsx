import { Button } from '@/components/ui/button.jsx';
import { categories } from '../data/menuData.js';

export function CategoryFilter({ selectedCategory, onCategoryChange }) {
  return (
    <div className="flex flex-wrap gap-2 justify-center mb-6">
      {categories.map((category) => (
        <Button
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          onClick={() => onCategoryChange(category.id)}
          className="flex items-center gap-2"
        >
          <span>{category.icon}</span>
          {category.name}
        </Button>
      ))}
    </div>
  );
}

