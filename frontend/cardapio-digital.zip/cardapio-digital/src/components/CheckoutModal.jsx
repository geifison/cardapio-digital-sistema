import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { Separator } from '@/components/ui/separator.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { CreditCard, Smartphone, MapPin, Clock, CheckCircle } from 'lucide-react';

export function CheckoutModal({ isOpen, onClose, cart, total }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    complement: '',
    paymentMethod: 'credit',
    cardNumber: '',
    cardName: '',
    cardExpiry: '',
    cardCvv: '',
    observations: ''
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNextStep = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = () => {
    // Simular processamento do pedido
    setStep(4);
    setTimeout(() => {
      onClose();
      setStep(1);
      setFormData({
        name: '',
        phone: '',
        email: '',
        address: '',
        complement: '',
        paymentMethod: 'credit',
        cardNumber: '',
        cardName: '',
        cardExpiry: '',
        cardCvv: '',
        observations: ''
      });
    }, 3000);
  };

  const renderStep1 = () => (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome completo</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          placeholder="Seu nome completo"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone">Telefone</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => handleInputChange('phone', e.target.value)}
          placeholder="(11) 99999-9999"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => handleInputChange('email', e.target.value)}
          placeholder="seu@email.com"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="address">Endereço de entrega</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => handleInputChange('address', e.target.value)}
          placeholder="Rua, número, bairro, cidade"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="complement">Complemento (opcional)</Label>
        <Input
          id="complement"
          value={formData.complement}
          onChange={(e) => handleInputChange('complement', e.target.value)}
          placeholder="Apartamento, bloco, referência"
        />
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-4">
      <div className="space-y-3">
        <Label>Forma de pagamento</Label>
        <RadioGroup
          value={formData.paymentMethod}
          onValueChange={(value) => handleInputChange('paymentMethod', value)}
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="credit" id="credit" />
            <Label htmlFor="credit" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Cartão de Crédito
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="debit" id="debit" />
            <Label htmlFor="debit" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Cartão de Débito
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="pix" id="pix" />
            <Label htmlFor="pix" className="flex items-center gap-2">
              <Smartphone className="w-4 h-4" />
              PIX
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="cash" id="cash" />
            <Label htmlFor="cash" className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Dinheiro na entrega
            </Label>
          </div>
        </RadioGroup>
      </div>

      {(formData.paymentMethod === 'credit' || formData.paymentMethod === 'debit') && (
        <div className="space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <Label htmlFor="cardNumber">Número do cartão</Label>
            <Input
              id="cardNumber"
              value={formData.cardNumber}
              onChange={(e) => handleInputChange('cardNumber', e.target.value)}
              placeholder="1234 5678 9012 3456"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cardName">Nome no cartão</Label>
            <Input
              id="cardName"
              value={formData.cardName}
              onChange={(e) => handleInputChange('cardName', e.target.value)}
              placeholder="Nome como está no cartão"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cardExpiry">Validade</Label>
              <Input
                id="cardExpiry"
                value={formData.cardExpiry}
                onChange={(e) => handleInputChange('cardExpiry', e.target.value)}
                placeholder="MM/AA"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cardCvv">CVV</Label>
              <Input
                id="cardCvv"
                value={formData.cardCvv}
                onChange={(e) => handleInputChange('cardCvv', e.target.value)}
                placeholder="123"
              />
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="observations">Observações (opcional)</Label>
        <Textarea
          id="observations"
          value={formData.observations}
          onChange={(e) => handleInputChange('observations', e.target.value)}
          placeholder="Alguma observação sobre o pedido?"
          rows={3}
        />
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-4">
      <div className="bg-muted p-4 rounded-lg space-y-3">
        <h4 className="font-semibold">Resumo do Pedido</h4>
        {cart.map((item) => (
          <div key={item.id} className="flex justify-between text-sm">
            <span>{item.quantity}x {item.name}</span>
            <span>R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}</span>
          </div>
        ))}
        <Separator />
        <div className="flex justify-between text-sm">
          <span>Subtotal:</span>
          <span>R$ {total.toFixed(2).replace('.', ',')}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span>Taxa de entrega:</span>
          <span>R$ 5,00</span>
        </div>
        <div className="flex justify-between font-bold">
          <span>Total:</span>
          <span>R$ {(total + 5).toFixed(2).replace('.', ',')}</span>
        </div>
      </div>

      <div className="bg-muted p-4 rounded-lg space-y-2">
        <h4 className="font-semibold flex items-center gap-2">
          <MapPin className="w-4 h-4" />
          Entrega
        </h4>
        <p className="text-sm">{formData.address}</p>
        {formData.complement && <p className="text-sm text-muted-foreground">{formData.complement}</p>}
      </div>

      <div className="bg-muted p-4 rounded-lg space-y-2">
        <h4 className="font-semibold flex items-center gap-2">
          <Clock className="w-4 h-4" />
          Tempo estimado
        </h4>
        <p className="text-sm">30-45 minutos</p>
      </div>

      <div className="bg-muted p-4 rounded-lg space-y-2">
        <h4 className="font-semibold">Pagamento</h4>
        <p className="text-sm">
          {formData.paymentMethod === 'credit' && 'Cartão de Crédito'}
          {formData.paymentMethod === 'debit' && 'Cartão de Débito'}
          {formData.paymentMethod === 'pix' && 'PIX'}
          {formData.paymentMethod === 'cash' && 'Dinheiro na entrega'}
        </p>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="text-center space-y-4">
      <CheckCircle className="w-16 h-16 text-green-600 mx-auto" />
      <h3 className="text-xl font-bold text-green-600">Pedido Confirmado!</h3>
      <p className="text-muted-foreground">
        Seu pedido foi recebido e está sendo preparado.
      </p>
      <Badge className="bg-green-600">
        Pedido #12345
      </Badge>
      <p className="text-sm text-muted-foreground">
        Você receberá atualizações por WhatsApp no número {formData.phone}
      </p>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {step === 1 && 'Dados de Entrega'}
            {step === 2 && 'Pagamento'}
            {step === 3 && 'Confirmar Pedido'}
            {step === 4 && 'Pedido Confirmado'}
          </DialogTitle>
          <DialogDescription>
            {step < 4 && `Etapa ${step} de 3`}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}
          {step === 4 && renderStep4()}
        </div>

        {step < 4 && (
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={step === 1 ? onClose : handlePrevStep}
            >
              {step === 1 ? 'Cancelar' : 'Voltar'}
            </Button>
            <Button
              onClick={step === 3 ? handleSubmit : handleNextStep}
              className="bg-green-600 hover:bg-green-700"
            >
              {step === 3 ? 'Confirmar Pedido' : 'Continuar'}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

