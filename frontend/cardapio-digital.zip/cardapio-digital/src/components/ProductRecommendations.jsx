import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plus, Star } from 'lucide-react';
import { getAllItems } from '../data/menuData.js';

export function ProductRecommendations({ currentItem, onAddToCart }) {
  const allItems = getAllItems();
  
  // Lógica simples de recomendação baseada na categoria
  const getRecommendations = (item) => {
    if (!item) return allItems.filter(i => i.popular).slice(0, 3);
    
    // Se for pizza, recomendar acompanhamentos
    if (item.category === 'pizza') {
      return allItems.filter(i => i.category === 'side' || i.category === 'hamburger').slice(0, 3);
    }
    
    // Se for hambúrguer, recomendar batatas e pizzas
    if (item.category === 'hamburger') {
      return allItems.filter(i => i.category === 'side' || i.category === 'pizza').slice(0, 3);
    }
    
    // Se for acompanhamento, recomendar pratos principais
    if (item.category === 'side') {
      return allItems.filter(i => i.category === 'pizza' || i.category === 'hamburger').slice(0, 3);
    }
    
    return allItems.filter(i => i.popular).slice(0, 3);
  };

  const recommendations = getRecommendations(currentItem);

  if (recommendations.length === 0) return null;

  return (
    <div className="mt-8 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Star className="w-5 h-5 text-orange-500" />
        <h3 className="text-lg font-semibold">Você também pode gostar</h3>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {recommendations.map((item) => (
          <Card key={item.id} className="overflow-hidden hover:shadow-md transition-shadow duration-200">
            <div className="relative">
              <img 
                src={item.image} 
                alt={item.name}
                className="w-full h-32 object-cover"
              />
              {item.popular && (
                <Badge className="absolute top-2 left-2 bg-orange-500 hover:bg-orange-600 text-xs">
                  <Star className="w-2 h-2 mr-1" />
                  Popular
                </Badge>
              )}
            </div>
            
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">{item.name}</CardTitle>
              <CardDescription className="text-xs line-clamp-2">
                {item.description}
              </CardDescription>
            </CardHeader>
            
            <CardFooter className="flex justify-between items-center pt-2">
              <div className="text-lg font-bold text-primary">
                R$ {item.price.toFixed(2).replace('.', ',')}
              </div>
              <Button 
                size="sm"
                onClick={() => onAddToCart(item)}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-3 h-3 mr-1" />
                Adicionar
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}

