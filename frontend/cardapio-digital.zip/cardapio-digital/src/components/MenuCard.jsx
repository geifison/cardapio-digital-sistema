import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plus, Star } from 'lucide-react';

export function MenuCard({ item, onAddToCart }) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img 
          src={item.image} 
          alt={item.name}
          className="w-full h-48 object-cover"
        />
        {item.popular && (
          <Badge className="absolute top-2 left-2 bg-orange-500 hover:bg-orange-600">
            <Star className="w-3 h-3 mr-1" />
            Popular
          </Badge>
        )}
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{item.name}</CardTitle>
        <CardDescription className="text-sm text-muted-foreground">
          {item.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pb-2">
        <div className="flex flex-wrap gap-1 mb-3">
          {item.ingredients.slice(0, 3).map((ingredient, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {ingredient}
            </Badge>
          ))}
          {item.ingredients.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{item.ingredients.length - 3}
            </Badge>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between items-center pt-2">
        <div className="text-2xl font-bold text-primary">
          R$ {item.price.toFixed(2).replace('.', ',')}
        </div>
        <Button 
          onClick={() => onAddToCart(item)}
          className="bg-green-600 hover:bg-green-700"
        >
          <Plus className="w-4 h-4 mr-1" />
          Adicionar
        </Button>
      </CardFooter>
    </Card>
  );
}

