import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Search, Star, Clock, Sparkles } from 'lucide-react'
import { MenuCard } from './components/MenuCard.jsx'
import { CategoryFilter } from './components/CategoryFilter.jsx'
import { CartSidebar } from './components/CartSidebar.jsx'
import { ProductRecommendations } from './components/ProductRecommendations.jsx'
import { getItemsByCategory, getPopularItems } from './data/menuData.js'
import './App.css'

function App() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [cart, setCart] = useState([])
  const [showPopular, setShowPopular] = useState(false)
  const [lastAddedItem, setLastAddedItem] = useState(null)

  const filteredItems = showPopular 
    ? getPopularItems()
    : getItemsByCategory(selectedCategory).filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
      )

  const addToCart = (item) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.id === item.id)
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      }
      return [...prevCart, { ...item, quantity: 1 }]
    })
    setLastAddedItem(item)
  }

  const updateQuantity = (id, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(id)
      return
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    )
  }

  const removeFromCart = (id) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id))
  }

  const handleCheckout = () => {
    // Limpar carrinho após checkout bem-sucedido
    setCart([])
    setLastAddedItem(null)
  }

  // Scroll suave para o topo quando mudar categoria
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [selectedCategory, showPopular])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4 sticky top-0 z-40 shadow-md">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Cardápio Digital</h1>
              <p className="text-sm opacity-90">Pizzaria & Hamburgueria</p>
            </div>
            <Badge variant="secondary" className="bg-green-600 text-white">
              <Clock className="w-3 h-3 mr-1" />
              Aberto
            </Badge>
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Buscar pratos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-background text-foreground"
            />
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4">
        {/* Popular Items Toggle */}
        <div className="flex justify-center mb-6">
          <Button
            variant={showPopular ? "default" : "outline"}
            onClick={() => setShowPopular(!showPopular)}
            className="flex items-center gap-2"
          >
            <Star className="w-4 h-4" />
            {showPopular ? 'Ver Todos' : 'Mais Populares'}
          </Button>
        </div>

        {/* Category Filter */}
        {!showPopular && (
          <CategoryFilter
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        )}

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredItems.map((item) => (
            <MenuCard
              key={item.id}
              item={item}
              onAddToCart={addToCart}
            />
          ))}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2">Nenhum item encontrado</h3>
            <p className="text-muted-foreground">
              Tente buscar por outro termo ou categoria
            </p>
          </div>
        )}

        {/* Product Recommendations */}
        {filteredItems.length > 0 && (
          <ProductRecommendations
            currentItem={lastAddedItem}
            onAddToCart={addToCart}
          />
        )}

        {/* Promotional Banner */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-lg mb-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles className="w-5 h-5" />
            <h3 className="text-lg font-bold">Oferta Especial!</h3>
            <Sparkles className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-90 mb-3">
            Frete grátis para pedidos acima de R$ 50,00
          </p>
          <Badge className="bg-white text-orange-500 font-semibold">
            Válido até o final do mês
          </Badge>
        </div>
      </main>

      {/* Cart Sidebar */}
      <CartSidebar
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
      />
    </div>
  )
}

export default App
