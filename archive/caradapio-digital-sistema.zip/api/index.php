<?php
/**
 * API Principal do Sistema de Cardápio Digital
 * Gerencia todas as requisições da API
 */

// Configurações de CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Responde a requisições OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Inclui arquivos necessários
require_once '../config/database.php';
require_once 'controllers/CategoryController.php';
require_once 'controllers/ProductController.php';
require_once 'controllers/OrderController.php';
require_once 'controllers/AuthController.php';

// Configuração de erro reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Função para capturar erros e retornar JSON
function handleError($errno, $errstr, $errfile, $errline) {
    $error = [
        'error' => true,
        'message' => 'Erro interno do servidor',
        'details' => $errstr . ' in ' . $errfile . ' on line ' . $errline
    ];
    echo json_encode($error);
    exit();
}

set_error_handler('handleError');

try {
    // Obtém a URI da requisição
    $request_uri = $_SERVER['REQUEST_URI'];
    $base_path = '/api/';
    
    // Remove o caminho base da URI
    if (strpos($request_uri, $base_path) === 0) {
        $request_uri = substr($request_uri, strlen($base_path));
    }
    
    // Remove query string
    $request_uri = strtok($request_uri, '?');
    
    // Divide a URI em segmentos
    $uri_segments = explode('/', trim($request_uri, '/'));
    $endpoint = $uri_segments[0] ?? '';
    $id = $uri_segments[1] ?? null;
    
    // Método HTTP
    $method = $_SERVER['REQUEST_METHOD'];
    
    // Obtém dados do corpo da requisição
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Inicializa conexão com banco de dados
    $database = new Database();
    $db = $database->getConnection();
    
    if (!$db) {
        throw new Exception('Erro de conexão com o banco de dados');
    }
    
    // Roteamento da API
    switch ($endpoint) {
        case 'categories':
            $controller = new CategoryController($db);
            handleCategoryRequests($controller, $method, $id, $input);
            break;
            
        case 'products':
            $controller = new ProductController($db);
            handleProductRequests($controller, $method, $id, $input);
            break;
            
        case 'orders':
            $controller = new OrderController($db);
            handleOrderRequests($controller, $method, $id, $input);
            break;
            
        case 'auth':
            $controller = new AuthController($db);
            handleAuthRequests($controller, $method, $id, $input);
            break;
            
        case 'health':
            echo json_encode([
                'status' => 'ok',
                'message' => 'API funcionando corretamente',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            break;
            
        default:
            http_response_code(404);
            echo json_encode([
                'error' => true,
                'message' => 'Endpoint não encontrado'
            ]);
            break;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'Erro interno do servidor',
        'details' => $e->getMessage()
    ]);
}

/**
 * Gerencia requisições para categorias
 */
function handleCategoryRequests($controller, $method, $id, $input) {
    switch ($method) {
        case 'GET':
            if ($id) {
                $controller->getById($id);
            } else {
                $controller->getAll();
            }
            break;
            
        case 'POST':
            $controller->create($input);
            break;
            
        case 'PUT':
            if ($id) {
                $controller->update($id, $input);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para atualização']);
            }
            break;
            
        case 'DELETE':
            if ($id) {
                $controller->delete($id);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para exclusão']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => true, 'message' => 'Método não permitido']);
            break;
    }
}

/**
 * Gerencia requisições para produtos
 */
function handleProductRequests($controller, $method, $id, $input) {
    switch ($method) {
        case 'GET':
            if ($id) {
                $controller->getById($id);
            } else {
                // Verifica se há filtro por categoria
                $category_id = $_GET['category_id'] ?? null;
                if ($category_id) {
                    $controller->getByCategory($category_id);
                } else {
                    $controller->getAll();
                }
            }
            break;
            
        case 'POST':
            $controller->create($input);
            break;
            
        case 'PUT':
            if ($id) {
                $controller->update($id, $input);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para atualização']);
            }
            break;
            
        case 'DELETE':
            if ($id) {
                $controller->delete($id);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para exclusão']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => true, 'message' => 'Método não permitido']);
            break;
    }
}

/**
 * Gerencia requisições para pedidos
 */
function handleOrderRequests($controller, $method, $id, $input) {
    switch ($method) {
        case 'GET':
            if ($id) {
                $controller->getById($id);
            } else {
                // Verifica filtros
                $status = $_GET['status'] ?? null;
                $date = $_GET['date'] ?? null;
                
                if ($status) {
                    $controller->getByStatus($status);
                } elseif ($date) {
                    $controller->getByDate($date);
                } else {
                    $controller->getAll();
                }
            }
            break;
            
        case 'POST':
            $controller->create($input);
            break;
            
        case 'PUT':
            if ($id) {
                $controller->update($id, $input);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para atualização']);
            }
            break;
            
        case 'DELETE':
            if ($id) {
                $controller->delete($id);
            } else {
                http_response_code(400);
                echo json_encode(['error' => true, 'message' => 'ID é obrigatório para exclusão']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => true, 'message' => 'Método não permitido']);
            break;
    }
}

/**
 * Gerencia requisições de autenticação
 */
function handleAuthRequests($controller, $method, $id, $input) {
    switch ($method) {
        case 'POST':
            if ($id === 'login') {
                $controller->login($input);
            } elseif ($id === 'logout') {
                $controller->logout();
            } else {
                http_response_code(404);
                echo json_encode(['error' => true, 'message' => 'Endpoint de autenticação não encontrado']);
            }
            break;
            
        case 'GET':
            if ($id === 'verify') {
                $controller->verifyToken();
            } else {
                http_response_code(404);
                echo json_encode(['error' => true, 'message' => 'Endpoint de autenticação não encontrado']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => true, 'message' => 'Método não permitido']);
            break;
    }
}
?>

