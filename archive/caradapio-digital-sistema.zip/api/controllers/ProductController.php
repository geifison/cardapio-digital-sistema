<?php
/**
 * Controller para gerenciamento de produtos
 */

class ProductController {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Retorna todos os produtos ativos
     */
    public function getAll() {
        try {
            $query = "SELECT p.*, c.name as category_name 
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.id 
                      WHERE p.active = 1 
                      ORDER BY p.display_order ASC, p.name ASC";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Converte valores booleanos
            foreach ($products as &$product) {
                $product['is_vegetarian'] = (bool) $product['is_vegetarian'];
                $product['is_vegan'] = (bool) $product['is_vegan'];
                $product['is_gluten_free'] = (bool) $product['is_gluten_free'];
                $product['is_spicy'] = (bool) $product['is_spicy'];
                $product['active'] = (bool) $product['active'];
                $product['price'] = (float) $product['price'];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $products
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao buscar produtos',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Retorna produtos por categoria
     */
    public function getByCategory($category_id) {
        try {
            $query = "SELECT p.*, c.name as category_name 
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.id 
                      WHERE p.category_id = :category_id AND p.active = 1 
                      ORDER BY p.display_order ASC, p.name ASC";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $stmt->execute();
            
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Converte valores booleanos
            foreach ($products as &$product) {
                $product['is_vegetarian'] = (bool) $product['is_vegetarian'];
                $product['is_vegan'] = (bool) $product['is_vegan'];
                $product['is_gluten_free'] = (bool) $product['is_gluten_free'];
                $product['is_spicy'] = (bool) $product['is_spicy'];
                $product['active'] = (bool) $product['active'];
                $product['price'] = (float) $product['price'];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $products
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao buscar produtos por categoria',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Retorna um produto específico por ID
     */
    public function getById($id) {
        try {
            $query = "SELECT p.*, c.name as category_name 
                      FROM products p 
                      LEFT JOIN categories c ON p.category_id = c.id 
                      WHERE p.id = :id AND p.active = 1";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($product) {
                // Converte valores booleanos
                $product['is_vegetarian'] = (bool) $product['is_vegetarian'];
                $product['is_vegan'] = (bool) $product['is_vegan'];
                $product['is_gluten_free'] = (bool) $product['is_gluten_free'];
                $product['is_spicy'] = (bool) $product['is_spicy'];
                $product['active'] = (bool) $product['active'];
                $product['price'] = (float) $product['price'];
                
                echo json_encode([
                    'success' => true,
                    'data' => $product
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Produto não encontrado'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao buscar produto',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Cria um novo produto
     */
    public function create($data) {
        try {
            // Validação dos dados obrigatórios
            if (empty($data['name']) || empty($data['category_id']) || !isset($data['price'])) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Nome, categoria e preço são obrigatórios'
                ]);
                return;
            }
            
            // Verifica se a categoria existe
            $category_query = "SELECT id FROM categories WHERE id = :category_id AND active = 1";
            $category_stmt = $this->db->prepare($category_query);
            $category_stmt->bindParam(':category_id', $data['category_id'], PDO::PARAM_INT);
            $category_stmt->execute();
            
            if (!$category_stmt->fetch()) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Categoria não encontrada'
                ]);
                return;
            }
            
            $query = "INSERT INTO products (
                        category_id, name, description, price, image_url, display_order, 
                        active, is_vegetarian, is_vegan, is_gluten_free, is_spicy, preparation_time
                      ) VALUES (
                        :category_id, :name, :description, :price, :image_url, :display_order,
                        :active, :is_vegetarian, :is_vegan, :is_gluten_free, :is_spicy, :preparation_time
                      )";
            
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':category_id', $data['category_id'], PDO::PARAM_INT);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description'] ?? '');
            $stmt->bindParam(':price', $data['price']);
            $stmt->bindParam(':image_url', $data['image_url'] ?? null);
            $stmt->bindParam(':display_order', $data['display_order'] ?? 0, PDO::PARAM_INT);
            $stmt->bindParam(':active', $data['active'] ?? true, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_vegetarian', $data['is_vegetarian'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_vegan', $data['is_vegan'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_gluten_free', $data['is_gluten_free'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_spicy', $data['is_spicy'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':preparation_time', $data['preparation_time'] ?? 0, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                $product_id = $this->db->lastInsertId();
                
                // Retorna o produto criado
                $this->getById($product_id);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao criar produto'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao criar produto',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Atualiza um produto existente
     */
    public function update($id, $data) {
        try {
            // Verifica se o produto existe
            $check_query = "SELECT id FROM products WHERE id = :id";
            $check_stmt = $this->db->prepare($check_query);
            $check_stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if (!$check_stmt->fetch()) {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Produto não encontrado'
                ]);
                return;
            }
            
            // Validação dos dados obrigatórios
            if (empty($data['name']) || empty($data['category_id']) || !isset($data['price'])) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Nome, categoria e preço são obrigatórios'
                ]);
                return;
            }
            
            // Verifica se a categoria existe
            $category_query = "SELECT id FROM categories WHERE id = :category_id AND active = 1";
            $category_stmt = $this->db->prepare($category_query);
            $category_stmt->bindParam(':category_id', $data['category_id'], PDO::PARAM_INT);
            $category_stmt->execute();
            
            if (!$category_stmt->fetch()) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Categoria não encontrada'
                ]);
                return;
            }
            
            $query = "UPDATE products SET 
                      category_id = :category_id,
                      name = :name, 
                      description = :description, 
                      price = :price,
                      image_url = :image_url, 
                      display_order = :display_order, 
                      active = :active,
                      is_vegetarian = :is_vegetarian,
                      is_vegan = :is_vegan,
                      is_gluten_free = :is_gluten_free,
                      is_spicy = :is_spicy,
                      preparation_time = :preparation_time,
                      updated_at = CURRENT_TIMESTAMP
                      WHERE id = :id";
            
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':category_id', $data['category_id'], PDO::PARAM_INT);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description'] ?? '');
            $stmt->bindParam(':price', $data['price']);
            $stmt->bindParam(':image_url', $data['image_url'] ?? null);
            $stmt->bindParam(':display_order', $data['display_order'] ?? 0, PDO::PARAM_INT);
            $stmt->bindParam(':active', $data['active'] ?? true, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_vegetarian', $data['is_vegetarian'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_vegan', $data['is_vegan'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_gluten_free', $data['is_gluten_free'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':is_spicy', $data['is_spicy'] ?? false, PDO::PARAM_BOOL);
            $stmt->bindParam(':preparation_time', $data['preparation_time'] ?? 0, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                // Retorna o produto atualizado
                $this->getById($id);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao atualizar produto'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao atualizar produto',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Exclui um produto (soft delete)
     */
    public function delete($id) {
        try {
            // Verifica se o produto existe
            $check_query = "SELECT id FROM products WHERE id = :id";
            $check_stmt = $this->db->prepare($check_query);
            $check_stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if (!$check_stmt->fetch()) {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Produto não encontrado'
                ]);
                return;
            }
            
            // Soft delete - marca como inativo
            $query = "UPDATE products SET active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Produto excluído com sucesso'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao excluir produto'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao excluir produto',
                'details' => $e->getMessage()
            ]);
        }
    }
}
?>

