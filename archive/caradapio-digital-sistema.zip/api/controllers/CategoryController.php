<?php
/**
 * Controller para gerenciamento de categorias
 */

class CategoryController {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Retorna todas as categorias ativas
     */
    public function getAll() {
        try {
            $query = "SELECT * FROM categories WHERE active = 1 ORDER BY display_order ASC, name ASC";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'data' => $categories
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao buscar categorias',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Retorna uma categoria específica por ID
     */
    public function getById($id) {
        try {
            $query = "SELECT * FROM categories WHERE id = :id AND active = 1";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($category) {
                echo json_encode([
                    'success' => true,
                    'data' => $category
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Categoria não encontrada'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao buscar categoria',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Cria uma nova categoria
     */
    public function create($data) {
        try {
            // Validação dos dados
            if (empty($data['name'])) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Nome da categoria é obrigatório'
                ]);
                return;
            }
            
            $query = "INSERT INTO categories (name, description, image_url, display_order, active) 
                      VALUES (:name, :description, :image_url, :display_order, :active)";
            
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description'] ?? '');
            $stmt->bindParam(':image_url', $data['image_url'] ?? null);
            $stmt->bindParam(':display_order', $data['display_order'] ?? 0, PDO::PARAM_INT);
            $stmt->bindParam(':active', $data['active'] ?? true, PDO::PARAM_BOOL);
            
            if ($stmt->execute()) {
                $category_id = $this->db->lastInsertId();
                
                // Retorna a categoria criada
                $this->getById($category_id);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao criar categoria'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao criar categoria',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Atualiza uma categoria existente
     */
    public function update($id, $data) {
        try {
            // Verifica se a categoria existe
            $check_query = "SELECT id FROM categories WHERE id = :id";
            $check_stmt = $this->db->prepare($check_query);
            $check_stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if (!$check_stmt->fetch()) {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Categoria não encontrada'
                ]);
                return;
            }
            
            // Validação dos dados
            if (empty($data['name'])) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Nome da categoria é obrigatório'
                ]);
                return;
            }
            
            $query = "UPDATE categories SET 
                      name = :name, 
                      description = :description, 
                      image_url = :image_url, 
                      display_order = :display_order, 
                      active = :active,
                      updated_at = CURRENT_TIMESTAMP
                      WHERE id = :id";
            
            $stmt = $this->db->prepare($query);
            
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':name', $data['name']);
            $stmt->bindParam(':description', $data['description'] ?? '');
            $stmt->bindParam(':image_url', $data['image_url'] ?? null);
            $stmt->bindParam(':display_order', $data['display_order'] ?? 0, PDO::PARAM_INT);
            $stmt->bindParam(':active', $data['active'] ?? true, PDO::PARAM_BOOL);
            
            if ($stmt->execute()) {
                // Retorna a categoria atualizada
                $this->getById($id);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao atualizar categoria'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao atualizar categoria',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Exclui uma categoria (soft delete)
     */
    public function delete($id) {
        try {
            // Verifica se a categoria existe
            $check_query = "SELECT id FROM categories WHERE id = :id";
            $check_stmt = $this->db->prepare($check_query);
            $check_stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $check_stmt->execute();
            
            if (!$check_stmt->fetch()) {
                http_response_code(404);
                echo json_encode([
                    'error' => true,
                    'message' => 'Categoria não encontrada'
                ]);
                return;
            }
            
            // Verifica se há produtos associados à categoria
            $products_query = "SELECT COUNT(*) as count FROM products WHERE category_id = :id AND active = 1";
            $products_stmt = $this->db->prepare($products_query);
            $products_stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $products_stmt->execute();
            $products_count = $products_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($products_count > 0) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Não é possível excluir categoria com produtos associados'
                ]);
                return;
            }
            
            // Soft delete - marca como inativa
            $query = "UPDATE categories SET active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Categoria excluída com sucesso'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'error' => true,
                    'message' => 'Erro ao excluir categoria'
                ]);
            }
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao excluir categoria',
                'details' => $e->getMessage()
            ]);
        }
    }
}
?>

