<?php
/**
 * Controller para gerenciamento de autenticação
 */

class AuthController {
    private $db;
    private $secret_key = 'cardapio_digital_secret_2024'; // Em produção, usar variável de ambiente
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    /**
     * Realiza login do usuário
     */
    public function login($data) {
        try {
            // Validação dos dados
            if (empty($data['email']) || empty($data['password'])) {
                http_response_code(400);
                echo json_encode([
                    'error' => true,
                    'message' => 'Email e senha são obrigatórios'
                ]);
                return;
            }
            
            // Busca o usuário
            $query = "SELECT id, name, email, password, role FROM users WHERE email = :email";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':email', $data['email']);
            $stmt->execute();
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($data['password'], $user['password'])) {
                http_response_code(401);
                echo json_encode([
                    'error' => true,
                    'message' => 'Credenciais inválidas'
                ]);
                return;
            }
            
            // Gera token JWT simples
            $token = $this->generateToken($user);
            
            // Inicia sessão
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            
            echo json_encode([
                'success' => true,
                'message' => 'Login realizado com sucesso',
                'data' => [
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'email' => $user['email'],
                        'role' => $user['role']
                    ],
                    'token' => $token
                ]
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao realizar login',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Realiza logout do usuário
     */
    public function logout() {
        try {
            session_start();
            session_destroy();
            
            echo json_encode([
                'success' => true,
                'message' => 'Logout realizado com sucesso'
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao realizar logout',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Verifica se o token é válido
     */
    public function verifyToken() {
        try {
            $headers = getallheaders();
            $token = null;
            
            // Busca o token no header Authorization
            if (isset($headers['Authorization'])) {
                $auth_header = $headers['Authorization'];
                if (preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
                    $token = $matches[1];
                }
            }
            
            // Verifica se há sessão ativa
            session_start();
            if (isset($_SESSION['user_id'])) {
                // Busca dados atualizados do usuário
                $query = "SELECT id, name, email, role FROM users WHERE id = :id";
                $stmt = $this->db->prepare($query);
                $stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);
                $stmt->execute();
                
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user) {
                    echo json_encode([
                        'success' => true,
                        'data' => [
                            'user' => $user,
                            'authenticated' => true
                        ]
                    ]);
                    return;
                }
            }
            
            // Se não há sessão, verifica o token
            if ($token) {
                $user_data = $this->verifyTokenData($token);
                if ($user_data) {
                    echo json_encode([
                        'success' => true,
                        'data' => [
                            'user' => $user_data,
                            'authenticated' => true
                        ]
                    ]);
                    return;
                }
            }
            
            http_response_code(401);
            echo json_encode([
                'error' => true,
                'message' => 'Token inválido ou expirado',
                'data' => [
                    'authenticated' => false
                ]
            ]);
            
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => true,
                'message' => 'Erro ao verificar token',
                'details' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Gera um token JWT simples
     */
    private function generateToken($user) {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'user_id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
            'exp' => time() + (24 * 60 * 60) // 24 horas
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $this->secret_key, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }
    
    /**
     * Verifica e decodifica um token JWT
     */
    private function verifyTokenData($token) {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }
            
            $header = base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[0]));
            $payload = base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1]));
            $signature = str_replace(['-', '_'], ['+', '/'], $parts[2]);
            
            // Verifica a assinatura
            $expected_signature = hash_hmac('sha256', $parts[0] . "." . $parts[1], $this->secret_key, true);
            $expected_signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($expected_signature));
            
            if ($signature !== $expected_signature) {
                return false;
            }
            
            $payload_data = json_decode($payload, true);
            
            // Verifica se o token não expirou
            if (isset($payload_data['exp']) && $payload_data['exp'] < time()) {
                return false;
            }
            
            // Busca dados atualizados do usuário
            $query = "SELECT id, name, email, role FROM users WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $payload_data['user_id'], PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Middleware para verificar autenticação
     */
    public static function requireAuth($db) {
        session_start();
        
        if (!isset($_SESSION['user_id'])) {
            // Verifica token no header
            $headers = getallheaders();
            $token = null;
            
            if (isset($headers['Authorization'])) {
                $auth_header = $headers['Authorization'];
                if (preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
                    $token = $matches[1];
                }
            }
            
            if (!$token) {
                http_response_code(401);
                echo json_encode([
                    'error' => true,
                    'message' => 'Acesso não autorizado'
                ]);
                exit();
            }
            
            $auth_controller = new AuthController($db);
            $user_data = $auth_controller->verifyTokenData($token);
            
            if (!$user_data) {
                http_response_code(401);
                echo json_encode([
                    'error' => true,
                    'message' => 'Token inválido'
                ]);
                exit();
            }
            
            // Define dados da sessão
            $_SESSION['user_id'] = $user_data['id'];
            $_SESSION['user_email'] = $user_data['email'];
            $_SESSION['user_role'] = $user_data['role'];
        }
        
        return $_SESSION;
    }
}
?>

