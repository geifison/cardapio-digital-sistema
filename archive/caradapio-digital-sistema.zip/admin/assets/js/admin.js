/**
 * Sistema de Painel Administrativo
 * JavaScript Principal
 */

// Configurações globais
const CONFIG = {
    API_BASE_URL: '../api/',
    REFRESH_INTERVAL: 5000, // 5 segundos
    SOUND_ENABLED: true,
    CURRENCY: 'R$'
};

// Estado global da aplicação
let appState = {
    user: null,
    orders: [],
    products: [],
    categories: [],
    isAuthenticated: false,
    currentSection: 'orders',
    refreshInterval: null,
    orderTimers: new Map()
};

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Inicializa a aplicação
 */
async function initializeApp() {
    try {
        // Verifica se há autenticação
        const isAuth = await checkAuthentication();
        
        if (isAuth) {
            hideLoginModal();
            await loadInitialData();
            setupEventListeners();
            startAutoRefresh();
        } else {
            showLoginModal();
        }
    } catch (error) {
        console.error('Erro ao inicializar aplicação:', error);
        showLoginModal();
    }
}

/**
 * Verifica autenticação
 */
async function checkAuthentication() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'auth/verify', {
            method: 'GET',
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success && data.data.authenticated) {
                appState.user = data.data.user;
                appState.isAuthenticated = true;
                updateUserInfo();
                return true;
            }
        }
        
        return false;
    } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        return false;
    }
}

/**
 * Realiza login
 */
async function login(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const loginData = {
        email: formData.get('email'),
        password: formData.get('password')
    };
    
    try {
        showLoading();
        
        const response = await fetch(CONFIG.API_BASE_URL + 'auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify(loginData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            appState.user = data.data.user;
            appState.isAuthenticated = true;
            
            hideLoginModal();
            updateUserInfo();
            await loadInitialData();
            setupEventListeners();
            startAutoRefresh();
        } else {
            showError(data.message || 'Erro ao fazer login');
        }
        
    } catch (error) {
        console.error('Erro no login:', error);
        showError('Erro de conexão. Tente novamente.');
    } finally {
        hideLoading();
    }
}

/**
 * Realiza logout
 */
async function logout() {
    try {
        await fetch(CONFIG.API_BASE_URL + 'auth/logout', {
            method: 'POST',
            credentials: 'include'
        });
        
        appState.user = null;
        appState.isAuthenticated = false;
        
        stopAutoRefresh();
        showLoginModal();
        
    } catch (error) {
        console.error('Erro no logout:', error);
    }
}

/**
 * Carrega dados iniciais
 */
async function loadInitialData() {
    try {
        await Promise.all([
            loadOrders(),
            loadProducts(),
            loadCategories()
        ]);
        
        updateDashboard();
    } catch (error) {
        console.error('Erro ao carregar dados iniciais:', error);
    }
}

/**
 * Carrega pedidos
 */
async function loadOrders() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'orders', {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                const previousOrdersCount = appState.orders.filter(order => order.status === 'novo').length;
                appState.orders = data.data;
                
                // Verifica se há novos pedidos para tocar som
                const currentNewOrdersCount = appState.orders.filter(order => order.status === 'novo').length;
                if (currentNewOrdersCount > previousOrdersCount && appState.isAuthenticated) {
                    playNotificationSound();
                }
                
                renderOrdersBoard();
                updateOrderTimers();
            }
        }
    } catch (error) {
        console.error('Erro ao carregar pedidos:', error);
    }
}

/**
 * Carrega produtos
 */
async function loadProducts() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'products', {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                appState.products = data.data;
                renderProductsGrid();
            }
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
    }
}

/**
 * Carrega categorias
 */
async function loadCategories() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'categories', {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                appState.categories = data.data;
                renderCategoriesGrid();
            }
        }
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}

/**
 * Renderiza o quadro de pedidos
 */
function renderOrdersBoard() {
    const newOrdersList = document.getElementById('newOrdersList');
    const productionOrdersList = document.getElementById('productionOrdersList');
    const deliveryOrdersList = document.getElementById('deliveryOrdersList');
    const completedOrdersList = document.getElementById('completedOrdersList');
    
    // Filtra pedidos por status
    const newOrders = appState.orders.filter(order => order.status === 'novo');
    const productionOrders = appState.orders.filter(order => order.status === 'aceito' || order.status === 'producao');
    const deliveryOrders = appState.orders.filter(order => order.status === 'entrega');
    const completedOrders = appState.orders.filter(order => order.status === 'finalizado').slice(0, 10); // Últimos 10
    
    // Atualiza contadores
    document.getElementById('newOrdersCount').textContent = newOrders.length;
    document.getElementById('productionOrdersCount').textContent = productionOrders.length;
    document.getElementById('deliveryOrdersCount').textContent = deliveryOrders.length;
    document.getElementById('completedOrdersCount').textContent = completedOrders.length;
    
    // Renderiza listas
    newOrdersList.innerHTML = newOrders.map(order => createOrderCard(order, 'new')).join('');
    productionOrdersList.innerHTML = productionOrders.map(order => createOrderCard(order, 'production')).join('');
    deliveryOrdersList.innerHTML = deliveryOrders.map(order => createOrderCard(order, 'delivery')).join('');
    completedOrdersList.innerHTML = completedOrders.map(order => createOrderCard(order, 'completed')).join('');
}

/**
 * Cria um card de pedido
 */
function createOrderCard(order, type) {
    const orderTime = new Date(order.created_at);
    const timeString = orderTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    
    const itemsText = order.items.slice(0, 2).map(item => `${item.quantity}x ${item.product_name}`).join(', ');
    const moreItems = order.items.length > 2 ? ` +${order.items.length - 2} itens` : '';
    
    let actions = '';
    let timer = '';
    
    // Timer para pedidos em produção
    if (type === 'production') {
        const startTime = new Date(order.accepted_at || order.created_at);
        const elapsed = Math.floor((Date.now() - startTime.getTime()) / 1000 / 60);
        const timerClass = elapsed > 30 ? 'warning' : elapsed > 45 ? 'danger' : 'normal';
        timer = `<div class="order-timer ${timerClass}">${elapsed}min</div>`;
    }
    
    // Botões de ação baseados no status
    switch (type) {
        case 'new':
            actions = `
                <button class="action-btn accept" onclick="updateOrderStatus(${order.id}, 'aceito')">
                    <i class="fas fa-check"></i> Aceitar
                </button>
            `;
            break;
        case 'production':
            actions = `
                <button class="action-btn print" onclick="showPrintModal(${order.id})">
                    <i class="fas fa-print"></i>
                </button>
                <button class="action-btn next" onclick="updateOrderStatus(${order.id}, 'entrega')">
                    <i class="fas fa-truck"></i>
                </button>
            `;
            break;
        case 'delivery':
            actions = `
                <button class="action-btn next" onclick="updateOrderStatus(${order.id}, 'finalizado')">
                    <i class="fas fa-check-circle"></i>
                </button>
            `;
            break;
    }
    
    return `
        <div class="order-card ${type}" onclick="showOrderDetail(${order.id})">
            ${timer}
            <div class="order-header">
                <span class="order-number">#${order.order_number}</span>
                <span class="order-time">${timeString}</span>
            </div>
            <div class="order-customer">
                <i class="fas fa-user"></i> ${order.customer_name}
            </div>
            <div class="order-items">
                ${itemsText}${moreItems}
            </div>
            <div class="order-footer">
                <span class="order-total">${formatCurrency(order.total_amount)}</span>
                <div class="order-actions" onclick="event.stopPropagation()">
                    ${actions}
                </div>
            </div>
        </div>
    `;
}

/**
 * Atualiza status do pedido
 */
async function updateOrderStatus(orderId, newStatus) {
    try {
        showLoading();
        
        const response = await fetch(CONFIG.API_BASE_URL + `orders/${orderId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ status: newStatus })
        });
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                await loadOrders();
                showSuccess('Status do pedido atualizado com sucesso!');
            } else {
                showError(data.message || 'Erro ao atualizar status');
            }
        } else {
            showError('Erro ao atualizar status do pedido');
        }
        
    } catch (error) {
        console.error('Erro ao atualizar status:', error);
        showError('Erro de conexão. Tente novamente.');
    } finally {
        hideLoading();
    }
}

/**
 * Mostra detalhes do pedido
 */
function showOrderDetail(orderId) {
    const order = appState.orders.find(o => o.id === orderId);
    if (!order) return;
    
    const modal = document.getElementById('orderDetailModal');
    const content = document.getElementById('orderDetailContent');
    const footer = document.getElementById('orderDetailFooter');
    
    // Calcula tempo decorrido
    const orderTime = new Date(order.created_at);
    const elapsed = Math.floor((Date.now() - orderTime.getTime()) / 1000 / 60);
    
    content.innerHTML = `
        <div class="order-detail">
            <div class="detail-section">
                <h4><i class="fas fa-info-circle"></i> Informações do Pedido</h4>
                <div class="detail-item">
                    <span>Número:</span>
                    <strong>#${order.order_number}</strong>
                </div>
                <div class="detail-item">
                    <span>Status:</span>
                    <strong>${getStatusText(order.status)}</strong>
                </div>
                <div class="detail-item">
                    <span>Data/Hora:</span>
                    <strong>${new Date(order.created_at).toLocaleString('pt-BR')}</strong>
                </div>
                <div class="detail-item">
                    <span>Tempo decorrido:</span>
                    <strong>${elapsed} minutos</strong>
                </div>
            </div>
            
            <div class="detail-section">
                <h4><i class="fas fa-user"></i> Dados do Cliente</h4>
                <div class="detail-item">
                    <span>Nome:</span>
                    <strong>${order.customer_name}</strong>
                </div>
                <div class="detail-item">
                    <span>Telefone:</span>
                    <strong>${order.customer_phone}</strong>
                </div>
                <div class="detail-item">
                    <span>Endereço:</span>
                    <strong>${order.customer_address}</strong>
                </div>
                ${order.customer_neighborhood ? `
                <div class="detail-item">
                    <span>Bairro:</span>
                    <strong>${order.customer_neighborhood}</strong>
                </div>
                ` : ''}
                ${order.customer_reference ? `
                <div class="detail-item">
                    <span>Referência:</span>
                    <strong>${order.customer_reference}</strong>
                </div>
                ` : ''}
            </div>
            
            <div class="detail-section">
                <h4><i class="fas fa-credit-card"></i> Pagamento</h4>
                <div class="detail-item">
                    <span>Forma:</span>
                    <strong>${getPaymentMethodText(order.payment_method)}</strong>
                </div>
                ${order.payment_value ? `
                <div class="detail-item">
                    <span>Valor pago:</span>
                    <strong>${formatCurrency(order.payment_value)}</strong>
                </div>
                <div class="detail-item">
                    <span>Troco:</span>
                    <strong>${formatCurrency(order.change_amount)}</strong>
                </div>
                ` : ''}
                <div class="detail-item">
                    <span>Total:</span>
                    <strong>${formatCurrency(order.total_amount)}</strong>
                </div>
            </div>
            
            <div class="detail-section">
                <h4><i class="fas fa-clock"></i> Timeline</h4>
                <div class="detail-item">
                    <span>Pedido criado:</span>
                    <strong>${new Date(order.created_at).toLocaleString('pt-BR')}</strong>
                </div>
                ${order.accepted_at ? `
                <div class="detail-item">
                    <span>Aceito em:</span>
                    <strong>${new Date(order.accepted_at).toLocaleString('pt-BR')}</strong>
                </div>
                ` : ''}
                ${order.production_started_at ? `
                <div class="detail-item">
                    <span>Produção iniciada:</span>
                    <strong>${new Date(order.production_started_at).toLocaleString('pt-BR')}</strong>
                </div>
                ` : ''}
                ${order.delivery_started_at ? `
                <div class="detail-item">
                    <span>Saiu para entrega:</span>
                    <strong>${new Date(order.delivery_started_at).toLocaleString('pt-BR')}</strong>
                </div>
                ` : ''}
                ${order.completed_at ? `
                <div class="detail-item">
                    <span>Finalizado em:</span>
                    <strong>${new Date(order.completed_at).toLocaleString('pt-BR')}</strong>
                </div>
                ` : ''}
            </div>
            
            <div class="detail-section order-items-detail">
                <h4><i class="fas fa-list"></i> Itens do Pedido</h4>
                <ul class="item-list">
                    ${order.items.map(item => `
                        <li>
                            <div>
                                <strong>${item.quantity}x ${item.product_name}</strong>
                                ${item.notes ? `<br><small>Obs: ${item.notes}</small>` : ''}
                            </div>
                            <span>${formatCurrency(item.subtotal)}</span>
                        </li>
                    `).join('')}
                </ul>
                <div class="detail-item" style="margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #bdc3c7;">
                    <span>Subtotal:</span>
                    <strong>${formatCurrency(order.total_amount - order.delivery_fee)}</strong>
                </div>
                <div class="detail-item">
                    <span>Taxa de entrega:</span>
                    <strong>${formatCurrency(order.delivery_fee)}</strong>
                </div>
                <div class="detail-item">
                    <span>Total:</span>
                    <strong>${formatCurrency(order.total_amount)}</strong>
                </div>
            </div>
            
            ${order.notes ? `
            <div class="detail-section">
                <h4><i class="fas fa-sticky-note"></i> Observações</h4>
                <p>${order.notes}</p>
            </div>
            ` : ''}
        </div>
    `;
    
    // Botões do footer baseados no status
    let footerButtons = '';
    switch (order.status) {
        case 'novo':
            footerButtons = `
                <button class="action-btn accept" onclick="updateOrderStatus(${order.id}, 'aceito'); closeOrderDetailModal();">
                    <i class="fas fa-check"></i> Aceitar Pedido
                </button>
            `;
            break;
        case 'aceito':
        case 'producao':
            footerButtons = `
                <button class="action-btn print" onclick="showPrintModal(${order.id})">
                    <i class="fas fa-print"></i> Imprimir Comandas
                </button>
                <button class="action-btn next" onclick="updateOrderStatus(${order.id}, 'entrega'); closeOrderDetailModal();">
                    <i class="fas fa-truck"></i> Enviar para Entrega
                </button>
            `;
            break;
        case 'entrega':
            footerButtons = `
                <button class="action-btn next" onclick="updateOrderStatus(${order.id}, 'finalizado'); closeOrderDetailModal();">
                    <i class="fas fa-check-circle"></i> Finalizar Pedido
                </button>
            `;
            break;
    }
    
    footer.innerHTML = `
        <button class="action-btn" onclick="closeOrderDetailModal()">
            <i class="fas fa-times"></i> Fechar
        </button>
        ${footerButtons}
    `;
    
    modal.classList.add('show');
}

/**
 * Fecha modal de detalhes do pedido
 */
function closeOrderDetailModal() {
    const modal = document.getElementById('orderDetailModal');
    modal.classList.remove('show');
}

/**
 * Mostra modal de impressão
 */
function showPrintModal(orderId) {
    appState.currentOrderId = orderId;
    const modal = document.getElementById('printModal');
    modal.classList.add('show');
}

/**
 * Fecha modal de impressão
 */
function closePrintModal() {
    const modal = document.getElementById('printModal');
    modal.classList.remove('show');
}

/**
 * Imprime comanda da cozinha
 */
function printKitchenOrder() {
    const order = appState.orders.find(o => o.id === appState.currentOrderId);
    if (!order) return;
    
    const printContent = `
        <div class="print-content">
            <h2 style="text-align: center; margin-bottom: 20px;">COMANDA DA COZINHA</h2>
            <div style="border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px;">
                <strong>Pedido #${order.order_number}</strong><br>
                <strong>Data/Hora:</strong> ${new Date(order.created_at).toLocaleString('pt-BR')}<br>
                <strong>Cliente:</strong> ${order.customer_name}
            </div>
            
            <h3>ITENS PARA PRODUÇÃO:</h3>
            <ul style="list-style: none; padding: 0;">
                ${order.items.map(item => `
                    <li style="margin-bottom: 15px; padding: 10px; border: 1px solid #ccc;">
                        <strong>${item.quantity}x ${item.product_name}</strong>
                        ${item.notes ? `<br><em>Observações: ${item.notes}</em>` : ''}
                    </li>
                `).join('')}
            </ul>
            
            ${order.notes ? `
            <div style="margin-top: 20px; padding: 10px; background: #f0f0f0;">
                <strong>Observações gerais:</strong><br>
                ${order.notes}
            </div>
            ` : ''}
            
            <div style="text-align: center; margin-top: 30px; font-size: 12px;">
                Impresso em: ${new Date().toLocaleString('pt-BR')}
            </div>
        </div>
    `;
    
    printDocument(printContent);
    closePrintModal();
}

/**
 * Imprime comanda do cliente
 */
function printCustomerOrder() {
    const order = appState.orders.find(o => o.id === appState.currentOrderId);
    if (!order) return;
    
    const printContent = `
        <div class="print-content">
            <h2 style="text-align: center; margin-bottom: 20px;">SABOR & CIA</h2>
            <div style="text-align: center; margin-bottom: 30px;">
                <strong>COMPROVANTE DE PEDIDO</strong>
            </div>
            
            <div style="border-bottom: 1px solid #000; padding-bottom: 10px; margin-bottom: 20px;">
                <strong>Pedido:</strong> #${order.order_number}<br>
                <strong>Data/Hora:</strong> ${new Date(order.created_at).toLocaleString('pt-BR')}<br>
                <strong>Status:</strong> ${getStatusText(order.status)}
            </div>
            
            <div style="margin-bottom: 20px;">
                <strong>CLIENTE:</strong><br>
                ${order.customer_name}<br>
                ${order.customer_phone}<br>
                ${order.customer_address}<br>
                ${order.customer_neighborhood ? order.customer_neighborhood + '<br>' : ''}
                ${order.customer_reference ? 'Ref: ' + order.customer_reference + '<br>' : ''}
            </div>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="border-bottom: 1px solid #000;">
                        <th style="text-align: left; padding: 5px;">Item</th>
                        <th style="text-align: center; padding: 5px;">Qtd</th>
                        <th style="text-align: right; padding: 5px;">Valor</th>
                    </tr>
                </thead>
                <tbody>
                    ${order.items.map(item => `
                        <tr>
                            <td style="padding: 5px;">${item.product_name}</td>
                            <td style="text-align: center; padding: 5px;">${item.quantity}</td>
                            <td style="text-align: right; padding: 5px;">${formatCurrency(item.subtotal)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            
            <div style="border-top: 1px solid #000; padding-top: 10px;">
                <div style="display: flex; justify-content: space-between;">
                    <span>Subtotal:</span>
                    <span>${formatCurrency(order.total_amount - order.delivery_fee)}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Taxa de entrega:</span>
                    <span>${formatCurrency(order.delivery_fee)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 18px; border-top: 1px solid #000; padding-top: 5px; margin-top: 5px;">
                    <span>TOTAL:</span>
                    <span>${formatCurrency(order.total_amount)}</span>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <strong>PAGAMENTO:</strong><br>
                Forma: ${getPaymentMethodText(order.payment_method)}<br>
                ${order.payment_value ? `Valor pago: ${formatCurrency(order.payment_value)}<br>` : ''}
                ${order.change_amount > 0 ? `Troco: ${formatCurrency(order.change_amount)}<br>` : ''}
            </div>
            
            ${order.notes ? `
            <div style="margin-top: 20px;">
                <strong>OBSERVAÇÕES:</strong><br>
                ${order.notes}
            </div>
            ` : ''}
            
            <div style="text-align: center; margin-top: 30px; font-size: 12px;">
                Obrigado pela preferência!<br>
                Impresso em: ${new Date().toLocaleString('pt-BR')}
            </div>
        </div>
    `;
    
    printDocument(printContent);
    closePrintModal();
}

/**
 * Imprime documento
 */
function printDocument(content) {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Impressão</title>
            <style>
                body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
                .print-content { max-width: 300px; margin: 0 auto; }
                table { width: 100%; }
                @media print {
                    body { margin: 0; }
                    .print-content { max-width: none; }
                }
            </style>
        </head>
        <body>
            ${content}
            <script>
                window.onload = function() {
                    window.print();
                    window.close();
                }
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

/**
 * Atualiza timers dos pedidos
 */
function updateOrderTimers() {
    const productionOrders = appState.orders.filter(order => 
        order.status === 'aceito' || order.status === 'producao'
    );
    
    productionOrders.forEach(order => {
        const startTime = new Date(order.accepted_at || order.created_at);
        const elapsed = Math.floor((Date.now() - startTime.getTime()) / 1000 / 60);
        
        const timerElement = document.querySelector(`[onclick="showOrderDetail(${order.id})"] .order-timer`);
        if (timerElement) {
            timerElement.textContent = `${elapsed}min`;
            
            // Atualiza classe baseada no tempo
            timerElement.className = 'order-timer';
            if (elapsed > 45) {
                timerElement.classList.add('danger');
            } else if (elapsed > 30) {
                timerElement.classList.add('warning');
            } else {
                timerElement.classList.add('normal');
            }
        }
    });
}

/**
 * Renderiza grade de produtos
 */
function renderProductsGrid() {
    const productsGrid = document.getElementById('productsGrid');
    
    if (appState.products.length === 0) {
        productsGrid.innerHTML = '<p>Nenhum produto cadastrado.</p>';
        return;
    }
    
    productsGrid.innerHTML = appState.products.map(product => `
        <div class="product-card">
            <div class="product-image">
                ${product.image_url ? 
                    `<img src="${product.image_url}" alt="${product.name}">` : 
                    '<i class="fas fa-utensils"></i>'
                }
            </div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <div class="product-price">${formatCurrency(product.price)}</div>
                <div class="product-category">${product.category_name}</div>
            </div>
        </div>
    `).join('');
}

/**
 * Renderiza grade de categorias
 */
function renderCategoriesGrid() {
    const categoriesGrid = document.getElementById('categoriesGrid');
    
    if (appState.categories.length === 0) {
        categoriesGrid.innerHTML = '<p>Nenhuma categoria cadastrada.</p>';
        return;
    }
    
    categoriesGrid.innerHTML = appState.categories.map(category => `
        <div class="category-card">
            <div class="category-info">
                <h3>${category.name}</h3>
                <p>${category.description || 'Sem descrição'}</p>
            </div>
        </div>
    `).join('');
}

/**
 * Atualiza dashboard com estatísticas
 */
function updateDashboard() {
    const today = new Date().toISOString().split('T')[0];
    const todayOrders = appState.orders.filter(order => 
        order.created_at.startsWith(today)
    );
    
    const todayRevenue = todayOrders
        .filter(order => order.status === 'finalizado')
        .reduce((sum, order) => sum + parseFloat(order.total_amount), 0);
    
    const completedOrders = todayOrders.filter(order => order.status === 'finalizado');
    const avgDeliveryTime = completedOrders.length > 0 
        ? Math.round(completedOrders.reduce((sum, order) => {
            const start = new Date(order.created_at);
            const end = new Date(order.completed_at);
            return sum + (end - start) / 1000 / 60;
        }, 0) / completedOrders.length)
        : 0;
    
    document.getElementById('todayOrdersCount').textContent = todayOrders.length;
    document.getElementById('todayRevenue').textContent = formatCurrency(todayRevenue);
    document.getElementById('avgDeliveryTime').textContent = `${avgDeliveryTime} min`;
}

/**
 * Configura event listeners
 */
function setupEventListeners() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', login);
    
    // Sound toggle
    document.getElementById('soundToggle').addEventListener('change', function() {
        CONFIG.SOUND_ENABLED = this.checked;
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeOrderDetailModal();
            closePrintModal();
        }
        
        if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
            e.preventDefault();
            refreshOrders();
        }
    });
}

/**
 * Mostra seção específica
 */
function showSection(sectionName) {
    // Remove active de todas as seções
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Ativa seção selecionada
    document.getElementById(sectionName + 'Section').classList.add('active');
    document.querySelector(`[onclick="showSection('${sectionName}')"]`).classList.add('active');
    
    appState.currentSection = sectionName;
}

/**
 * Atualiza informações do usuário
 */
function updateUserInfo() {
    if (appState.user) {
        document.getElementById('userName').textContent = appState.user.name;
    }
}

/**
 * Inicia atualização automática
 */
function startAutoRefresh() {
    if (appState.refreshInterval) {
        clearInterval(appState.refreshInterval);
    }
    
    appState.refreshInterval = setInterval(() => {
        if (appState.currentSection === 'orders') {
            loadOrders();
        }
    }, CONFIG.REFRESH_INTERVAL);
}

/**
 * Para atualização automática
 */
function stopAutoRefresh() {
    if (appState.refreshInterval) {
        clearInterval(appState.refreshInterval);
        appState.refreshInterval = null;
    }
}

/**
 * Atualiza pedidos manualmente
 */
async function refreshOrders() {
    await loadOrders();
    showSuccess('Pedidos atualizados!');
}

/**
 * Toca som de notificação
 */
function playNotificationSound() {
    if (CONFIG.SOUND_ENABLED) {
        const audio = document.getElementById('notificationSound');
        if (audio) {
            audio.play().catch(e => console.log('Erro ao tocar som:', e));
        }
    }
}

/**
 * Mostra/oculta modais
 */
function showLoginModal() {
    document.getElementById('loginOverlay').style.display = 'flex';
}

function hideLoginModal() {
    document.getElementById('loginOverlay').style.display = 'none';
}

function showLoading() {
    document.getElementById('loadingOverlay').classList.add('show');
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.remove('show');
}

/**
 * Funções utilitárias
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function getStatusText(status) {
    const statusMap = {
        'novo': 'Novo',
        'aceito': 'Aceito',
        'producao': 'Em Produção',
        'entrega': 'Em Entrega',
        'finalizado': 'Finalizado',
        'cancelado': 'Cancelado'
    };
    return statusMap[status] || status;
}

function getPaymentMethodText(method) {
    const methodMap = {
        'dinheiro': 'Dinheiro',
        'cartao': 'Cartão',
        'pix': 'PIX'
    };
    return methodMap[method] || method;
}

function showError(message) {
    alert('Erro: ' + message);
}

function showSuccess(message) {
    alert('Sucesso: ' + message);
}

// Expõe funções globais necessárias
window.showSection = showSection;
window.logout = logout;
window.refreshOrders = refreshOrders;
window.updateOrderStatus = updateOrderStatus;
window.showOrderDetail = showOrderDetail;
window.closeOrderDetailModal = closeOrderDetailModal;
window.showPrintModal = showPrintModal;
window.closePrintModal = closePrintModal;
window.printKitchenOrder = printKitchenOrder;
window.printCustomerOrder = printCustomerOrder;

