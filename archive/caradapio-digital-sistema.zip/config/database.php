<?php
/**
 * Configuração do Banco de Dados
 * Sistema de Cardápio Digital
 */

class Database {
    private $host = 'localhost';
    private $db_name = 'cardapio_digital';
    private $username = 'root'; // Altere conforme sua configuração
    private $password = ''; // Altere conforme sua configuração
    private $charset = 'utf8mb4';
    public $conn;

    /**
     * Conecta ao banco de dados MySQL
     */
    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $exception) {
            echo "Erro de conexão: " . $exception->getMessage();
        }

        return $this->conn;
    }

    /**
     * Executa o script de criação do banco de dados
     */
    public function createDatabase() {
        try {
            // Conecta sem especificar o banco para criar o banco
            $dsn = "mysql:host=" . $this->host . ";charset=" . $this->charset;
            $conn = new PDO($dsn, $this->username, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Cria o banco de dados se não existir
            $sql = "CREATE DATABASE IF NOT EXISTS " . $this->db_name . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            $conn->exec($sql);
            
            echo "Banco de dados criado com sucesso!<br>";
            
            // Conecta ao banco criado
            $this->conn = $this->getConnection();
            
            // Lê e executa o arquivo SQL
            $sql_file = __DIR__ . '/../database_schema.sql';
            if (file_exists($sql_file)) {
                $sql_content = file_get_contents($sql_file);
                
                // Divide o conteúdo em comandos individuais
                $commands = explode(';', $sql_content);
                
                foreach ($commands as $command) {
                    $command = trim($command);
                    if (!empty($command) && !preg_match('/^--/', $command)) {
                        $this->conn->exec($command);
                    }
                }
                
                echo "Tabelas criadas e dados iniciais inseridos com sucesso!<br>";
            } else {
                echo "Arquivo database_schema.sql não encontrado!<br>";
            }
            
        } catch(PDOException $e) {
            echo "Erro ao criar banco de dados: " . $e->getMessage() . "<br>";
        }
    }
}

/**
 * Configurações gerais da aplicação
 */
class Config {
    // URL base da aplicação
    public static $base_url = 'http://localhost/cardapio-digital/';
    
    // Configurações de upload de imagens
    public static $upload_path = 'uploads/';
    public static $max_file_size = 5242880; // 5MB
    public static $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    
    // Configurações de pedidos
    public static $default_delivery_time = 30; // minutos
    public static $default_delivery_fee = 5.00; // R$
    
    // Configurações de notificação sonora
    public static $sound_enabled = true;
    public static $sound_file = 'assets/sounds/notification.mp3';
}
?>

