/**
 * Sistema de Cardápio Digital
 * JavaScript Principal
 */

// Configurações globais
const CONFIG = {
    API_BASE_URL: 'api/',
    DELIVERY_FEE: 5.00,
    CURRENCY: 'R$'
};

// Estado global da aplicação
let appState = {
    categories: [],
    products: [],
    cart: [],
    currentCategory: null,
    isCartOpen: false
};

// Inicialização da aplicação
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Inicializa a aplicação
 */
async function initializeApp() {
    try {
        await loadCategories();
        await loadProducts();
        setupEventListeners();
        updateCartDisplay();
    } catch (error) {
        console.error('Erro ao inicializar aplicação:', error);
        showError('Erro ao carregar o cardápio. Tente recarregar a página.');
    }
}

/**
 * Carrega as categorias do backend
 */
async function loadCategories() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'categories');
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                appState.categories = data.data;
                renderCategories();
            } else {
                throw new Error(data.message || 'Erro ao carregar categorias');
            }
        } else {
            throw new Error('Erro na requisição das categorias');
        }
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
        // Fallback para dados simulados em caso de erro
        appState.categories = [
            { id: 1, name: 'Lanches', description: 'Hambúrgueres e sanduíches' },
            { id: 2, name: 'Pizzas', description: 'Pizzas tradicionais e especiais' },
            { id: 3, name: 'Bebidas', description: 'Refrigerantes e sucos' },
            { id: 4, name: 'Sobremesas', description: 'Doces e sobremesas' },
            { id: 5, name: 'Pratos Executivos', description: 'Refeições completas' }
        ];
        renderCategories();
    }
}

/**
 * Carrega os produtos do backend
 */
async function loadProducts() {
    try {
        const response = await fetch(CONFIG.API_BASE_URL + 'products');
        
        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                appState.products = data.data;
                renderProducts();
            } else {
                throw new Error(data.message || 'Erro ao carregar produtos');
            }
        } else {
            throw new Error('Erro na requisição dos produtos');
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        // Fallback para dados simulados em caso de erro
        appState.products = [
            {
                id: 1,
                category_id: 1,
                name: 'X-Burger Clássico',
                description: 'Hambúrguer bovino, queijo, alface, tomate, cebola e molho especial',
                price: 15.90,
                image_url: null,
                is_vegetarian: false,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 15
            },
            {
                id: 2,
                category_id: 1,
                name: 'X-Salada',
                description: 'Hambúrguer bovino, queijo, alface, tomate, cebola, ovo e batata palha',
                price: 18.90,
                image_url: null,
                is_vegetarian: false,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 15
            },
            {
                id: 3,
                category_id: 1,
                name: 'X-Vegetariano',
                description: 'Hambúrguer de soja, queijo, alface, tomate, cebola e molho especial',
                price: 16.90,
                image_url: null,
                is_vegetarian: true,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 12
            },
            {
                id: 4,
                category_id: 2,
                name: 'Pizza Margherita',
                description: 'Molho de tomate, mussarela, manjericão e azeite',
                price: 32.90,
                image_url: null,
                is_vegetarian: true,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 25
            },
            {
                id: 5,
                category_id: 2,
                name: 'Pizza Calabresa',
                description: 'Molho de tomate, mussarela, calabresa e cebola',
                price: 35.90,
                image_url: null,
                is_vegetarian: false,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 25
            },
            {
                id: 6,
                category_id: 3,
                name: 'Coca-Cola 350ml',
                description: 'Refrigerante de cola gelado',
                price: 4.50,
                image_url: null,
                is_vegetarian: true,
                is_spicy: false,
                is_gluten_free: true,
                preparation_time: 2
            },
            {
                id: 7,
                category_id: 3,
                name: 'Suco de Laranja Natural',
                description: 'Suco natural de laranja 300ml',
                price: 6.90,
                image_url: null,
                is_vegetarian: true,
                is_spicy: false,
                is_gluten_free: true,
                preparation_time: 5
            },
            {
                id: 8,
                category_id: 4,
                name: 'Pudim de Leite',
                description: 'Pudim caseiro com calda de caramelo',
                price: 8.90,
                image_url: null,
                is_vegetarian: true,
                is_spicy: false,
                is_gluten_free: false,
                preparation_time: 5
            }
        ];
        renderProducts();
    }
}

/**
 * Renderiza as categorias na navegação
 */
function renderCategories() {
    const categoriesList = document.getElementById('categoriesList');
    
    const allCategoriesItem = document.createElement('div');
    allCategoriesItem.className = 'category-item active';
    allCategoriesItem.textContent = 'Todos';
    allCategoriesItem.onclick = () => filterByCategory(null);
    categoriesList.appendChild(allCategoriesItem);
    
    appState.categories.forEach(category => {
        const categoryItem = document.createElement('div');
        categoryItem.className = 'category-item';
        categoryItem.textContent = category.name;
        categoryItem.onclick = () => filterByCategory(category.id);
        categoriesList.appendChild(categoryItem);
    });
}

/**
 * Renderiza os produtos na grade
 */
function renderProducts(filteredProducts = null) {
    const productsGrid = document.getElementById('productsGrid');
    const products = filteredProducts || appState.products;
    
    productsGrid.innerHTML = '';
    
    products.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

/**
 * Cria um card de produto
 */
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const badges = [];
    if (product.is_vegetarian) badges.push('<span class="badge vegetarian">Vegetariano</span>');
    if (product.is_spicy) badges.push('<span class="badge spicy">Picante</span>');
    if (product.is_gluten_free) badges.push('<span class="badge gluten-free">Sem Glúten</span>');
    
    card.innerHTML = `
        <div class="product-image">
            ${product.image_url ? 
                `<img src="${product.image_url}" alt="${product.name}">` : 
                '<i class="fas fa-utensils"></i>'
            }
            <div class="product-badges">
                ${badges.join('')}
            </div>
        </div>
        <div class="product-info">
            <h3 class="product-name">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-footer">
                <span class="product-price">${formatCurrency(product.price)}</span>
                <button class="add-to-cart" onclick="addToCart(${product.id})">
                    <i class="fas fa-plus"></i>
                    Adicionar
                </button>
            </div>
        </div>
    `;
    
    return card;
}

/**
 * Filtra produtos por categoria
 */
function filterByCategory(categoryId) {
    appState.currentCategory = categoryId;
    
    // Atualiza visual das categorias
    document.querySelectorAll('.category-item').forEach(item => {
        item.classList.remove('active');
    });
    
    if (categoryId === null) {
        document.querySelector('.category-item').classList.add('active');
        renderProducts();
    } else {
        const filteredProducts = appState.products.filter(product => product.category_id === categoryId);
        renderProducts(filteredProducts);
        
        // Encontra e marca a categoria ativa
        const categoryItems = document.querySelectorAll('.category-item');
        const category = appState.categories.find(cat => cat.id === categoryId);
        if (category) {
            categoryItems.forEach(item => {
                if (item.textContent === category.name) {
                    item.classList.add('active');
                }
            });
        }
    }
}

/**
 * Adiciona produto ao carrinho
 */
function addToCart(productId) {
    const product = appState.products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = appState.cart.find(item => item.product.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        appState.cart.push({
            product: product,
            quantity: 1,
            notes: ''
        });
    }
    
    updateCartDisplay();
    showCartAnimation();
}

/**
 * Remove produto do carrinho
 */
function removeFromCart(productId) {
    appState.cart = appState.cart.filter(item => item.product.id !== productId);
    updateCartDisplay();
}

/**
 * Atualiza quantidade de um item no carrinho
 */
function updateCartItemQuantity(productId, newQuantity) {
    const item = appState.cart.find(item => item.product.id === productId);
    if (!item) return;
    
    if (newQuantity <= 0) {
        removeFromCart(productId);
    } else {
        item.quantity = newQuantity;
        updateCartDisplay();
    }
}

/**
 * Atualiza a exibição do carrinho
 */
function updateCartDisplay() {
    const cartCount = document.getElementById('cartCount');
    const cartItems = document.getElementById('cartItems');
    const cartEmpty = document.getElementById('cartEmpty');
    const cartFooter = document.getElementById('cartFooter');
    const cartSubtotal = document.getElementById('cartSubtotal');
    const deliveryFee = document.getElementById('deliveryFee');
    const cartTotal = document.getElementById('cartTotal');
    
    const totalItems = appState.cart.reduce((sum, item) => sum + item.quantity, 0);
    const subtotal = appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const total = subtotal + CONFIG.DELIVERY_FEE;
    
    cartCount.textContent = totalItems;
    
    if (appState.cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartFooter.style.display = 'none';
        cartItems.innerHTML = '';
    } else {
        cartEmpty.style.display = 'none';
        cartFooter.style.display = 'block';
        
        cartItems.innerHTML = '';
        appState.cart.forEach(item => {
            const cartItem = createCartItem(item);
            cartItems.appendChild(cartItem);
        });
        
        cartSubtotal.textContent = formatCurrency(subtotal);
        deliveryFee.textContent = formatCurrency(CONFIG.DELIVERY_FEE);
        cartTotal.textContent = formatCurrency(total);
    }
}

/**
 * Cria um item do carrinho
 */
function createCartItem(item) {
    const cartItem = document.createElement('div');
    cartItem.className = 'cart-item';
    
    cartItem.innerHTML = `
        <div class="cart-item-image">
            ${item.product.image_url ? 
                `<img src="${item.product.image_url}" alt="${item.product.name}">` : 
                '<i class="fas fa-utensils"></i>'
            }
        </div>
        <div class="cart-item-info">
            <div class="cart-item-name">${item.product.name}</div>
            <div class="cart-item-price">${formatCurrency(item.product.price)}</div>
            <div class="quantity-controls">
                <button class="quantity-btn" onclick="updateCartItemQuantity(${item.product.id}, ${item.quantity - 1})">
                    <i class="fas fa-minus"></i>
                </button>
                <span class="quantity">${item.quantity}</span>
                <button class="quantity-btn" onclick="updateCartItemQuantity(${item.product.id}, ${item.quantity + 1})">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
        </div>
        <button class="remove-item" onclick="removeFromCart(${item.product.id})">
            <i class="fas fa-trash"></i>
        </button>
    `;
    
    return cartItem;
}

/**
 * Alterna a exibição do carrinho
 */
function toggleCart() {
    const cartSidebar = document.getElementById('cartSidebar');
    const cartOverlay = document.getElementById('cartOverlay');
    
    appState.isCartOpen = !appState.isCartOpen;
    
    if (appState.isCartOpen) {
        cartSidebar.classList.add('open');
        cartOverlay.classList.add('show');
        document.body.style.overflow = 'hidden';
    } else {
        cartSidebar.classList.remove('open');
        cartOverlay.classList.remove('show');
        document.body.style.overflow = '';
    }
}

/**
 * Procede para o checkout
 */
function proceedToCheckout() {
    if (appState.cart.length === 0) {
        showError('Seu carrinho está vazio!');
        return;
    }
    
    populateCheckoutModal();
    showCheckoutModal();
}

/**
 * Popula o modal de checkout com os dados do carrinho
 */
function populateCheckoutModal() {
    const checkoutItems = document.getElementById('checkoutItems');
    const checkoutSubtotal = document.getElementById('checkoutSubtotal');
    const checkoutDeliveryFee = document.getElementById('checkoutDeliveryFee');
    const checkoutTotal = document.getElementById('checkoutTotal');
    
    const subtotal = appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const total = subtotal + CONFIG.DELIVERY_FEE;
    
    checkoutItems.innerHTML = '';
    appState.cart.forEach(item => {
        const checkoutItem = document.createElement('div');
        checkoutItem.className = 'checkout-item';
        checkoutItem.innerHTML = `
            <span>${item.quantity}x ${item.product.name}</span>
            <span>${formatCurrency(item.product.price * item.quantity)}</span>
        `;
        checkoutItems.appendChild(checkoutItem);
    });
    
    checkoutSubtotal.textContent = formatCurrency(subtotal);
    checkoutDeliveryFee.textContent = formatCurrency(CONFIG.DELIVERY_FEE);
    checkoutTotal.textContent = formatCurrency(total);
}

/**
 * Exibe o modal de checkout
 */
function showCheckoutModal() {
    const checkoutModal = document.getElementById('checkoutModal');
    checkoutModal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

/**
 * Fecha o modal de checkout
 */
function closeCheckoutModal() {
    const checkoutModal = document.getElementById('checkoutModal');
    checkoutModal.classList.remove('show');
    document.body.style.overflow = '';
}

/**
 * Submete o pedido
 */
async function submitOrder() {
    const form = document.getElementById('checkoutForm');
    const formData = new FormData(form);
    
    // Validação básica
    if (!validateCheckoutForm(formData)) {
        return;
    }
    
    const orderData = {
        customer_name: formData.get('customerName'),
        customer_phone: formData.get('customerPhone'),
        customer_address: formData.get('customerAddress'),
        customer_neighborhood: formData.get('customerNeighborhood'),
        customer_reference: formData.get('customerReference'),
        payment_method: formData.get('paymentMethod'),
        payment_value: formData.get('paymentValue') || null,
        notes: formData.get('orderNotes'),
        items: appState.cart.map(item => ({
            product_id: item.product.id,
            product_name: item.product.name,
            product_price: item.product.price,
            quantity: item.quantity,
            notes: item.notes
        })),
        subtotal: appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0),
        delivery_fee: CONFIG.DELIVERY_FEE,
        total_amount: appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0) + CONFIG.DELIVERY_FEE
    };
    
    // Calcula o troco se necessário
    if (orderData.payment_method === 'dinheiro' && orderData.payment_value) {
        orderData.change_amount = parseFloat(orderData.payment_value) - orderData.total_amount;
    }
    
    try {
        showLoadingOverlay();
        
        // Simula envio do pedido - substituir pela chamada real da API
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const orderNumber = generateOrderNumber();
        
        hideLoadingOverlay();
        closeCheckoutModal();
        showSuccessModal(orderNumber);
        
        // Limpa o carrinho
        appState.cart = [];
        updateCartDisplay();
        toggleCart();
        
    } catch (error) {
        hideLoadingOverlay();
        console.error('Erro ao enviar pedido:', error);
        showError('Erro ao processar pedido. Tente novamente.');
    }
}

/**
 * Valida o formulário de checkout
 */
function validateCheckoutForm(formData) {
    const requiredFields = ['customerName', 'customerPhone', 'customerAddress', 'customerNeighborhood'];
    
    for (const field of requiredFields) {
        if (!formData.get(field) || formData.get(field).trim() === '') {
            showError(`Por favor, preencha o campo ${getFieldLabel(field)}.`);
            return false;
        }
    }
    
    // Validação específica para pagamento em dinheiro
    const paymentMethod = formData.get('paymentMethod');
    const paymentValue = formData.get('paymentValue');
    const totalAmount = appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0) + CONFIG.DELIVERY_FEE;
    
    if (paymentMethod === 'dinheiro' && paymentValue && parseFloat(paymentValue) < totalAmount) {
        showError('O valor para pagamento deve ser maior ou igual ao total do pedido.');
        return false;
    }
    
    return true;
}

/**
 * Retorna o rótulo do campo para mensagens de erro
 */
function getFieldLabel(fieldName) {
    const labels = {
        customerName: 'Nome Completo',
        customerPhone: 'Telefone',
        customerAddress: 'Endereço',
        customerNeighborhood: 'Bairro'
    };
    return labels[fieldName] || fieldName;
}

/**
 * Gera um número de pedido único
 */
function generateOrderNumber() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `PED${timestamp.toString().slice(-6)}${random.toString().padStart(3, '0')}`;
}

/**
 * Exibe o modal de sucesso
 */
function showSuccessModal(orderNumber) {
    const successModal = document.getElementById('successModal');
    const orderNumberElement = document.getElementById('orderNumber');
    
    orderNumberElement.textContent = orderNumber;
    successModal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

/**
 * Fecha o modal de sucesso
 */
function closeSuccessModal() {
    const successModal = document.getElementById('successModal');
    successModal.classList.remove('show');
    document.body.style.overflow = '';
}

/**
 * Exibe overlay de carregamento
 */
function showLoadingOverlay() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.classList.add('show');
}

/**
 * Oculta overlay de carregamento
 */
function hideLoadingOverlay() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.classList.remove('show');
}

/**
 * Exibe animação do carrinho
 */
function showCartAnimation() {
    const cartCount = document.getElementById('cartCount');
    cartCount.style.animation = 'none';
    setTimeout(() => {
        cartCount.style.animation = 'bounce 0.6s ease-in-out';
    }, 10);
}

/**
 * Configura os event listeners
 */
function setupEventListeners() {
    // Event listener para mudança no método de pagamento
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', function() {
            const moneySection = document.getElementById('moneySection');
            if (this.value === 'dinheiro') {
                moneySection.style.display = 'block';
            } else {
                moneySection.style.display = 'none';
                document.getElementById('paymentValue').value = '';
                document.getElementById('changeDisplay').style.display = 'none';
            }
        });
    });
    
    // Event listener para cálculo do troco
    document.getElementById('paymentValue').addEventListener('input', function() {
        const paymentValue = parseFloat(this.value) || 0;
        const totalAmount = appState.cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0) + CONFIG.DELIVERY_FEE;
        const changeDisplay = document.getElementById('changeDisplay');
        const changeAmount = document.getElementById('changeAmount');
        
        if (paymentValue > totalAmount) {
            const change = paymentValue - totalAmount;
            changeAmount.textContent = formatCurrency(change);
            changeDisplay.style.display = 'block';
        } else {
            changeDisplay.style.display = 'none';
        }
    });
    
    // Event listener para fechar modais com ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (document.getElementById('checkoutModal').classList.contains('show')) {
                closeCheckoutModal();
            }
            if (document.getElementById('successModal').classList.contains('show')) {
                closeSuccessModal();
            }
            if (appState.isCartOpen) {
                toggleCart();
            }
        }
    });
}

/**
 * Formata valor monetário
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

/**
 * Exibe mensagem de erro
 */
function showError(message) {
    // Implementação simples - pode ser melhorada com um sistema de notificações mais sofisticado
    alert(message);
}

/**
 * Exibe mensagem de sucesso
 */
function showSuccess(message) {
    // Implementação simples - pode ser melhorada com um sistema de notificações mais sofisticado
    alert(message);
}

// Funções utilitárias para debug (remover em produção)
window.appState = appState;
window.CONFIG = CONFIG;

