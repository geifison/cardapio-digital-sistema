<?php
/**
 * Instalador do Sistema de Cardápio Digital
 * Execute este arquivo uma vez para configurar o banco de dados
 */

require_once __DIR__ . '/config/database.php';

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Cardápio Digital</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        .step {
            margin: 20px 0;
            padding: 15px;
            border-left: 4px solid #007bff;
            background-color: #f8f9fa;
        }
        .success {
            color: #28a745;
            border-left-color: #28a745;
        }
        .error {
            color: #dc3545;
            border-left-color: #dc3545;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .warning {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍽️ Instalação do Sistema de Cardápio Digital</h1>
            <p>Configure seu sistema de cardápio digital em poucos passos</p>
        </div>

        <?php if (!isset($_POST['install'])): ?>
            <div class="warning">
                <strong>⚠️ Atenção:</strong> Antes de continuar, certifique-se de que:
                <ul>
                    <li>O MySQL está instalado e funcionando</li>
                    <li>Você tem permissões para criar bancos de dados</li>
                    <li>As configurações de conexão em <code>config/database.php</code> estão corretas</li>
                </ul>
            </div>

            <form method="post">
                <div class="step">
                    <h3>📋 O que será instalado:</h3>
                    <ul>
                        <li>Banco de dados <strong>cardapio_digital</strong></li>
                        <li>Tabelas necessárias para o sistema</li>
                        <li>Dados iniciais (categorias e produtos de exemplo)</li>
                        <li>Usuário administrador padrão</li>
                    </ul>
                </div>

                <div class="step">
                    <h3>👤 Credenciais do Administrador:</h3>
                    <p><strong>Email:</strong> admin@cardapio.com</p>
                    <p><strong>Senha:</strong> admin123</p>
                    <p><em>⚠️ Altere essas credenciais após o primeiro login!</em></p>
                </div>

                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" name="install" class="btn">🚀 Instalar Sistema</button>
                </div>
            </form>

        <?php else: ?>
            <div class="step">
                <h3>📦 Iniciando instalação...</h3>
            </div>

            <?php
            try {
                $database = new Database();
                $database->createDatabase();
                
                echo '<div class="step success">';
                echo '<h3>✅ Instalação concluída com sucesso!</h3>';
                echo '<p>O sistema foi instalado e está pronto para uso.</p>';
                echo '</div>';
                
                echo '<div class="step">';
                echo '<h3>🎯 Próximos passos:</h3>';
                echo '<ol>';
                echo '<li>Acesse o <a href="admin/">painel administrativo</a></li>';
                echo '<li>Faça login com as credenciais: admin@cardapio.com / admin123</li>';
                echo '<li>Altere a senha padrão</li>';
                echo '<li>Configure seus produtos e categorias</li>';
                echo '<li>Acesse o <a href="index.php">cardápio digital</a> para testar</li>';
                echo '</ol>';
                echo '</div>';
                
                echo '<div class="warning">';
                echo '<strong>🔒 Segurança:</strong> Após a instalação, remova ou renomeie este arquivo (install.php) por segurança.';
                echo '</div>';
                
            } catch (Exception $e) {
                echo '<div class="step error">';
                echo '<h3>❌ Erro na instalação</h3>';
                echo '<p>Erro: ' . $e->getMessage() . '</p>';
                echo '<p>Verifique as configurações de banco de dados e tente novamente.</p>';
                echo '</div>';
            }
            ?>

        <?php endif; ?>
    </div>
</body>
</html>

